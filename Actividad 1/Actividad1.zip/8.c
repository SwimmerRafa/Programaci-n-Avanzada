#include "stdio.h"


int main(void) {
printf("#include \"stdio.h\"");
puts("\n");
puts("\n");
puts("int main(void) {");
printf("printf(\"Hello World\\n\");");
printf("\n");
puts("return 0;");
puts("}");
return 0;
}