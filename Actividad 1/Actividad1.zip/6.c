#include <stdio.h>

int main() {
    puts("A \"quoted\" String is 'much' better if you learn the rules of \"escape sequences.\" Also, \"\" represents an empty String. Don't forget: use \\\" instead of \" ! \'\' is not the same as \"");
}

