#include <stdio.h>

int main(){
    int cont;

    printf("//////////////////////\n");

    for(cont =0; cont <= 4; cont ++){
        printf("|| Victory is mine! ||\n");
        printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\n");
    }
}