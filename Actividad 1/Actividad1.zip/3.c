#include <stdio.h>

int main(void){
    printf("//////////////////////\n");
    printf("|| Victory is mine! ||\n");
    printf("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
    return 0;
}