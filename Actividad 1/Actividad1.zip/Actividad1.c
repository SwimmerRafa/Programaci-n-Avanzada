#include<stdio.h>

int main(void){
    printf("What is the difference between\n");
    printf("a ' and a \"?  Or between a \" and a \\\"?\n");
    printf("\n");
    printf("One is what we see when we're typing our program.\n");
    printf("The other is what appears on the \"console.\"");
    return 0;
}