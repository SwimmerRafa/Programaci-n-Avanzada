#include<stdio.h>


int mantra(void){
    printf("There's one thing every coder must understand:\nThe printf command.\n");
}

int main(void){
    mantra();
    printf("\n");
    mantra();

}
