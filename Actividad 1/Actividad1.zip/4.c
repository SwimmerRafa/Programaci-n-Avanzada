#include <stdio.h>

int main(void){
    puts("  \\/\n");
    puts(" \\\\//\n");
    puts("\\\\\\///\n");
    puts("///\\\\\\\n");
    puts(" //\\\\\n");
    puts("  /\\\n");
    return 0;
}