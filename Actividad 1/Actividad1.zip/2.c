#include<stdio.h>

int main(void){
    puts("/ \\ // \\\\ /// \\\\\\");
    return 0;
}
