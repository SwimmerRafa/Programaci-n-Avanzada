#include <stdio.h>
int main() {
  int i;
  for (i = -4; i < 87; i=i+18){
    printf("%d \n", i);
  }
}