#include<stdio.h>

int main(){
    int i;
    for(i=1; i<5; i++){
        printf("2 times %d = %d \n",i, 2*i);
    }
}   