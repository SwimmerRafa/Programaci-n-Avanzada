#include<stdio.h>

int main(){
    int n= 3;
    int m= 1;
    for(int i = 1; i <= n; i++){
        for(int j= 0; j < m; j++){
            printf("000111222333444555666777888999");
        }
        printf("\n");
    }
}