#include<stdio.h>

int main(){
    int m=4;
    int n=5;
    for(int i=1 ; i < m+1;i++){
        for(int j=1; j < n+1; j++){
            printf("u");
        }
        printf("\n");
    }
}

