#include<stdio.h>

int main(){
    int m = 1;
    int n = 6;
    for(int i = 1; i < m+1; i++){
        for(int j= 1; j< n+1; j++){
            printf("         |");
        }
        printf("\n 123456789012345678901234567890123456789012345678901234567890");
    }
}