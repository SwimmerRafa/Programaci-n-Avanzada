#include<stdio.h>

int main(){
    int n;
    scanf("%i", &n);

    if(n % 2 ==  0){
        printf("even");
    }
    else{
        printf("odd");
    }
    
}