#include<stdio.h>

int main (){
    int i;
    scanf("%i", &i);

    printf("%i times 2 = %i", i, i*2);
}